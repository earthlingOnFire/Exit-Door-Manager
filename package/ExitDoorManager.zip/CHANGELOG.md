<details>
<summary>Changelog 1.1.0</summary>

- Added level randomizer.
</details>

<details>
<summary>Changelog 1.0.2</summary>

- Updated to Patch 16.
- Added Cyber Grind exit option.
- Added Sandbox exit option.
- Added Main Menu exit option.
- Added option to close game on level exit.
</details>

<details>
<summary>Changelog 1.0.1</summary>

- Updated to Patch 15.
</details>
